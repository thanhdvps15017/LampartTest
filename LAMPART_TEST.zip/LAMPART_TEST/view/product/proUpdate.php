
<div class="mt-3">
    <form action="index.php?act=proUpload" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <input value="<?=$getId['name']?>" type="text" name="name" class="form-control" placeholder="Tên sản phẩm">
        </div>
        <div class="form-group row mt-2">
            <div class="col-6">
                <select class="form-select" name="iddm">
                    <option value="0">Chọn danh mục</option>
                    <?php 
                        $iddmNew = $getId['iddm'];
                        foreach ($loadAll as $load) {
                            if($load['id'] == $iddmNew){
                                echo '<option value="'.$load['id'].'" selected>'.$load['name'].'</option>';
                            }else{
                                echo '<option value="'.$load['id'].'">'.$load['name'].'</option>';
                            }
                            
                        }
                    ?>
                </select>
            </div>
            <div class="col-4">
                <input name="img" class="form-control" type="file">
            </div>
            <div class="col-2 mt-2"><?php echo  $getId['img']; ?></div>
        <div class="mt-2">
            <input type="submit" name="btn" class="btn btn-primary" style="width: 200px" value="Sửa">
            <input type="hidden" name="id" VALUE="<?=$getId['id']?>">
        </div>
        
        <hr class="mt-2">
    </form>

    