
<div class="mt-3">
    <form action="index.php?act=proAdd" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <input type="text" name="name" class="form-control" placeholder="Tên sản phẩm">
        </div>
        <div class="form-group row mt-2">
            <div class="col-6">
                <select class="form-select" name="iddm">
                    <option selected>Chọn loại sản phẩm</option>
                    <?php 
                        foreach ($loadAll as $load) {
                            echo '
                                <option value="'.$load['id'].'">'.$load['name'].'</option>
                            ';
                        }
                    ?>
                </select>
            </div>
            <div class="col-6">
                    <input name="img" class="form-control" type="file">
            </div>
        <div class="mt-2">
            <input type="submit" name="submit" class="btn btn-primary" style="width: 200px" value="Thêm">
        </div>
        
        <hr class="mt-2">
    </form>

    <div>
        <table class="table mt-2">
          <thead>
            <tr>
              <th scope="col">STT</th>
              <th scope="col">Tên sản phẩm</th>
              <th scope="col">Hình ảnh</th>
              <th scope="col">Hành động</th>
            </tr>
          </thead>
          <tbody>
            <form action="index.php?act=proTim" method="POST">
                        Search: <input type="text" name="keys" />
                        <button type="submit" name="submit">search</button>
            </form>
            <?php $i=1;  
              foreach ($loadAllPro as $load) {
                echo '
                  <tr>
                    <th scope="row">'.$i.'</th>
                    <td>'.$load['name'].'</td>
                    <td>'.$load['img'].'</td>
                    
                    <td>
                      <a class="btn btn-primary" href="index.php?act=proEdit&id='.$load['id'].'" style="width:20%">Sửa</a>
                      <a class="btn btn-danger" href="index.php?act=proRemove&id='.$load['id'].'" style="width:20%">Xoá</a>
                    </td>
                  </tr>
                ';
                $i++;
              }
            ?>
          </tbody>
        </table>
      </div>


      <style>
        ul.list-trang{
          padding: 0;
          margin: 0;
          list-style: none;
        }
        ul.list-trang li{
          float: left;
          padding: 5px 13px;
          margin: 5px;
          background: burlywood;
          display: block; 
        }
        ul.list-trang li a{
          color: #000;
          text-align: center;
          text-decoration: none;
        }
      </style>
    <div>
      <ul class="list-trang">
        <?php for ($i=1; $i <= 5; $i++) { ?>
          <li><a href="index.php?act=pro&page=<?=$i?>"><?php echo $i ?></a></li>
        <?php } ?>

      </ul>
    </div>
  </div>
</body>
</html>