  <div class="mt-3">
    <form action="index.php?act=cataAdd" method="POST">
      <div class="form-group row">
        <div class="col-10"><input type="text" name="name" class="form-control" placeholder="Thêm loại sản phẩm"></div>
        <div class="col-2"><input type="submit" name="submit" class="btn btn-primary" style="width: 200px" value="Thêm"></div>
      </div><hr>

      <div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">STT</th>
              <th scope="col">Tên loại sản phẩm</th>
              <th scope="col">Hành động</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1;
              foreach ($loadAll as $load) {
                echo '
                  <tr>
                    <th scope="row">'.$i.'</th>
                    <td>'.$load['name'].'</td>
                    <td>
                      <a class="btn btn-primary" href="index.php?act=cataEdit&id='.$load['id'].'" style="width:20%">Sửa</a>
                      <a class="btn btn-danger" href="index.php?act=cataRemove&id='.$load['id'].'" style="width:20%">Xoá</a>
                    </td>
                  </tr>
                ';
                $i++;
              }
            ?>
          </tbody>
        </table>
      </div>
    </form>
  </div>
</body>
</html>