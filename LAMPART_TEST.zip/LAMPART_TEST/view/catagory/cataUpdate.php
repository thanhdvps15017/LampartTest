<div class="mt-3">
    <form action="index.php?act=cataUpload" method="POST">
      <div class="form-group row">
        <div class="col-10">
          <input type="text" name="name" class="form-control " VALUE="<?=$getId['name']?>">
          <input type="hidden" name="id" VALUE="<?=$getId['id']?>">
        </div>
        <div class="col-2"> 
          <input type="submit" name="btn" class="btn btn-primary" style="width: 200px" VALUES="Cập nhập">
        </div>
      </div>
      <hr>
    </form>
  </div>
</body>
</html>