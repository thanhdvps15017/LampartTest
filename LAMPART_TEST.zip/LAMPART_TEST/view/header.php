<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="jquery-3.6.1.min.js"></script>
</head>
<body>
    <div class="container mt-2"> 
        <div>
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link" href="index.php?act=cata">Categories</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="index.php?act=pro">Products</a>
                      </li>
                    </ul>
                    <!-- <form action="index.php?act=proTim" method="POST">
                        Search: <input type="text" name="keys" />
                        <button type="submit" name="submit">search</button>
                    </form> -->

                  </div>
                </div>
            </nav>
        </div>