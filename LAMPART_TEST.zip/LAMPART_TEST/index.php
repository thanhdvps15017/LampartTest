<?php 
    include('./model/connect.php');
    include('./model/catagory.php');
    include('./model/product.php');

    include './view/header.php';

    if (isset($_GET['act'])){
        $act = $_GET['act'];
        switch ($act) {
        //load trang danh mục
            case 'cata':
                $cata = new Catagory();
                $loadAll = $cata->cataLoadAll();
                include './view/catagory/cata.php';
                break;
        //Thêm mới danh mục
            case 'cataAdd':
                if (isset($_POST['submit'])) {
                    $cata = new Catagory();
                    $name = $_POST['name'];
                    $insert = $cata->cataAdd($name);
                }
                header('location: index.php?act=cata');
                break;
        //xoá danh mục    
            case 'cataRemove':
                $cata = new Catagory();
                if (isset($_GET['id'])){
                    $id = $_GET['id'];   
                    $del = $cata->cataRemove($id);
                    header('location: index.php?act=cata');
                }
                break;
        // Load trang sửa danh mục
             case 'cataEdit':
                $cata = new Catagory();
                if (isset($_GET['id'])){
                    $id = $_GET['id'];
                    $getId = $cata->cataGetId($id);
                    include './view/catagory/cataUpdate.php';
                }
                break;
        // Sửa danh mục
            case 'cataUpload':
                $cata = new Catagory();
                if (isset($_POST['btn'])) {
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    echo $name;
                    $up = $cata->cataUpload($id, $name);
                    header('location: index.php?act=cata');
                }
                break;


        //Load trang sản phẩm        
            case 'pro':
                //load danh sách danh mục
                $cata = new Catagory();
                $loadAll = $cata->cataLoadAll();
                //load danh sách sản phẩm
                $pro = new Product();
                $loadAllPro = $pro->proLoadAll();
                include './view/product/product.php';
                break;
        //thêm sản phẩm mới
            case 'proAdd':
                $pro = new Product();
                if (isset($_POST['submit'])) {
                    $name = $_POST['name'];
                    $iddm = $_POST['iddm'];
                    //upload hình ảnh
                    $img = basename($_FILES['img']['name']);
                    $target_dir = "./upload/";
                    $target_file = $target_dir . $img;
                    $insert = $pro->proAdd($name, $img, $iddm);
                }
                header('location: index.php?act=pro');
                break;
        //Xoá sản phẩm
            case 'proRemove': 
                $pro = new Product();
                    if (isset($_GET['id'])){
                        $id = $_GET['id'];   
                        $del = $pro->proRemove($id);
                        header('location: index.php?act=pro');
                    }
                    break;
        //load trang sửa sản phẩm
            case 'proEdit':
                $cata = new Catagory();
                $loadAll = $cata->cataLoadAll();

                $pro = new Product();
                if (isset($_GET['id'])){
                    $id = $_GET['id'];
                    $getId = $pro->proGetId($id);
                }
                include './view/product/proUpdate.php';
                break;
        // sửa sản phẩm
            case 'proUpload':
                $pro = new Product();
                if (isset($_POST['btn'])) {
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $iddm = $_POST['iddm'];
                    $img = basename($_FILES['img']['name']);
                    $target_dir = "./upload/";
                    $target_file = $target_dir . $img;


                    $up = $pro->proUpload($id, $name, $img, $iddm);

                    header('location: index.php?act=pro');
                }
                break;
                
        //Tìm kiếm sản phẩm
            case 'proTim':
                $cata = new Catagory();
                $loadAll = $cata->cataLoadAll();
                $pro = new Product();
                if (isset( $_POST['submit'])) {
                    $keys = $_POST['keys'];
                    $tim = $pro->proTim($keys);
                    include './view/product/productTim.php';
                }
                break;
        
            default:
                include './view/home.php';
                break;
        }
    } else {
        include './view/home.php';
    }
?>