<?php 
    class Product{
        var $id=null;
        var $name=null;
        var $price=null;
        var $img=null;
        var $iddm=null; 
        
        public function construct__ (){
            // $this->id;
            // $this->name;
            if (func_get_args() == 5) {
                $this->id->func_get_arg(0);
                $this->name->func_get_arg(1);
                $this->price->func_get_arg(2);
                $this->img->func_get_arg(3);
                $this->iddm->func_get_arg(4);
            }
        }
    // Thêm sản phẩm
        public function proAdd($name, $img, $iddm){
            $conn = new connect();
            $sql = "INSERT INTO Products (name, img, iddm) 
                    VALUE ('".$name."', '".$img."', '".$iddm."')";
            $result = $conn->execute($sql);
            return $result;
        }
    // Lấy toàn bộ sản phẩm
        public function proLoadAll(){
            $conn = new connect();
            if(isset($_GET['page'])){ 
                $page = $_GET['page']; 
            } else { 
                    $page = 1; 
                }
            $row = 5;
            $from = ($page - 1) * $row;
            $sql = "SELECT*FROM Products ORDER By id DESC LIMIT $from,$row";
            $result = $conn->getList($sql);
            return $result;
        }
    // Xoá sản phẩm
        public function proRemove($id){
            $conn = new connect();
            $sql = "DELETE FROM Products WHERE id=".$id;
            $result = $conn->execute($sql);
            return $result;
        }
    //lấy sản phẩm theo id
        public function proGetId($id){
            $conn = new connect();
            $sql="SELECT*FROM Products WHERE id = '".$id."'";
            $result=$conn->getInstance($sql);
            return $result;
        }
    //sửa sản phẩm
        public function proUpload($id, $name, $img, $iddm){
            $conn = new connect();
            $sql = "UPDATE Products SET name='".$name."', img='".$img."', iddm='".$iddm."' WHERE id = ".$id;
            $result = $conn->execute($sql);
            return $result;
        }
    //tìm kiếm
        public function proTim($keys){
            $conn = new connect();
            $sql = "SELECT*FROM Products WHERE name LIKE '%$keys%'";
            $result = $conn->getList ($sql);
            return $result;
        }

    }

?>