<?php
// namespace core_admin;
// use PDO;
class connect
{
    var $db=null;
    function __construct(){
        $dsn="mysql:host=localhost;dbname=lampart_test";
        $user= 'root';
        $password = '';
        $this->db=new PDO($dsn,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    // gửi câu truy vấn lấy nguyên bảng đi
    function getList ($select){
        $result= $this->db->query($select);
        $result=$result->fetchAll();
        return $result;
    }
    // lấy 1 dòng đi
    function getInstance($select){
        $results= $this->db->query($select);
        $result=$results->fetch();
        return $result;
    }
    // thêm dữ liệu
    function execute($query){
        $result= $this->db->exec($query);
        return $result;
    }
}
