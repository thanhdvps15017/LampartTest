<?php 
    class Catagory{
        var $id=null;
        var $name=null;
        
        public function construct__ (){
            // $this->id;
            // $this->name;
            if (func_get_args() == 2) {
                $this->id->func_get_arg(0);
                $this->name->func_get_arg(1);
              }
        }
    //them danh mục
        public function cataAdd($name){
            $conn = new connect();
            $sql = "INSERT INTO Catagory (name) VALUE ('".$name."')";
            $result = $conn->execute($sql);
            return $result;
        }
    //lấy toàn bộ danh mục
        public function cataLoadAll(){
            $conn = new connect();
            $sql = "SELECT*FROM Catagory";
            $result = $conn->getList($sql);
            return $result;
        }
    //xoá danh mục
        public function cataRemove($id){
            $conn = new connect();
            $sql = "DELETE FROM Catagory WHERE id=".$id;
            $result = $conn->execute($sql);
            return $result;
        }
    //lấy danh mục theo id
        public function cataGetId($id){
            $conn = new connect();
            $sql="SELECT*FROM Catagory WHERE id = '".$id."'";
            $result=$conn->getInstance($sql);
            return $result;
        }
    //sửa danh mục
        public function cataUpload($id, $name){
            $conn = new connect();
            $sql = "UPDATE Catagory SET name = '$name' WHERE id = ".$id;
            $result = $conn->execute($sql);
            return $result;
        }
        
    }
?>